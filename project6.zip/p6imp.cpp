#include <cstdlib>
#include <iostream>
#include <fstream>
#include <ctime>
#include "p6spec.h"
#include "stringFunctions.h"

using namespace std;

//*************SYMBOL DEFAULT CONSTRUCTOR & ~DESTRUCTOR***************
symbol::symbol(){
	name = NULL;
	value = 0;
	bonus = false;
}

symbol::~symbol(){
	delete []name;
	name = NULL;
	value = 0;
	bonus = false;
	//cout << "end symbol destructor" << endl;
}

//**************REEL DEFAULT CONSTRUCTOR & ~DESTRUCTOR****************
reel::reel(){
	srand(time(NULL));
	stopPtr = new symbol[10];
	payline = 0;
}

reel::~reel(){
	delete []stopPtr;
	stopPtr = NULL;
	payline = 0;
	//cout << "end reel destructor" << endl;
}

//***************SYMBOL COPY FUNCTION******************************
void symbol::symbolCopy(const symbol &s){

	//int length = strLen(s.name);

	name = new char[strLen(s.name)+1];
	strCopy(name, s.name);
	value = s.value;
	bonus = s.bonus;
}

//***************REEL COPY FUNCTION***************************************
void reel::reelCopy(const reel &r){

	for(int i=0; i<10; i++){
		stopPtr[i] = r.stopPtr[i];
	}

	payline = r.payline;
}

//************************SYMBOL SET FUNCTIONS***************************
//function: set name
//purpose: set name of each symbol
void symbol::setName(char *tempName){

	//determine length of symbol name;
	int length = strLen(tempName);
	//cout << length << endl;

	//allocate memory for symbol name;
	name = new char[length + 1];
	//cout << "test" << endl;

	//copy symbol name into perfectly sized array
	strCopy(name, tempName);

	//test
	//cout << "test" << endl;
	//cout << name << endl;
}

//function: set value
//purpose: set value of each associated symbol
void symbol::setValue(int val){	
	//if(val > 0){
	value = val;
	//}
	//else
	//val = 0;

	//cout << value << endl;
}

//function: set bonus
//purpose: set bonus depending on if value is > 0
void symbol::setBonus(int val){
	bonus = false;	

	if(val > 0){
		bonus = true;
	}

	//cout << bonus << endl;
}

//*********************SYMBOL GET FUNCTIONS***************************

//function: get name
//purpose: get name of symbol
char* symbol::getName() const{

	//cout << name << endl;
	return name;

}

//function: get value
//purpose: get value associated with symbol
int symbol::getValue() const{
	
	//cout << value << endl;
	return value;
}

//function: get bonus
//purpose: determine is symbol has a value or not
bool symbol::getBonus() const{

	//cout << bonus << endl;
	return bonus;
}

//*****************************SYMBOL PRINT FUNCTION*************************

void symbol::printSym(){
	cout << name;
}

void symbol::printVal(){
	cout << value;
}

//***************************REEL SET FUNCTION********************************

//function: set reel name
//purpose: set reel name
void reel::setReel(symbol *symPtr, reel *reelPtr){
	//srand(time(NULL));
	int random;
	//for(int i=0; i<3; i++){
		for(int j=0; j<10; j++){
			random = rand()%6;
					
			//cout << random << endl;
			//cout << random;
			stopPtr[j].setName( symPtr[random].getName() );
			stopPtr[j].setValue( symPtr[random].getValue() );
			stopPtr[j].setBonus( symPtr[random].getBonus() );

			//cout << "test" << endl;
			//cout << reelPtr[i].stopPtr[j].getName() << endl;
		}
	//}
}

//*****************************REEL PRINT FUNCTION*****************************
//function: print reel
//purpose: print reel config to screen
void reel::printReel(reel *reelPtr){
	for(int i=0; i<10; i++){
		for(int j=0; j<3; j++){
			reelPtr[j].stopPtr[i].printSym();
			cout << '\t';
						
		}
		cout << endl;

	}
}

//*****************************PICK AND PRINT FUNCTION***************************
//function: pick and print
//purpose: pick reel # and stop # and print corresponding symbol and value
void reel::pickAndPrint(reel *reelPtr){
	int row;
	int col;
	int i=0;	

	cout << "Pick a Reel # 1-3 and Press Enter" << endl;
	cin >> col;
	col--;
	cout << "Pick a Stop # 1-10 and Press Enter" << endl;
	cin >> row;
	row--;
	cout << endl << endl << endl << endl;
	cout << endl << endl << endl << endl;

	reelPtr[col].stopPtr[row].printSym();
	cout << '\t';
	reelPtr[col].stopPtr[row].printVal();

}

//**************************SPIN REEL FUNCTION************************************
//function: spin reel
//purpose: simulate spinning the reels
void reel::spinReels(reel *reelPtr){

	int random;
	int sum = 0;

	for(int i=0; i<3; i++){
		random = rand()%6;
		reelPtr[i].stopPtr[random].printSym();
		sum = sum + reelPtr[i].stopPtr[random].getValue();
		cout << '\t';
		
	}
	cout << sum;

}

