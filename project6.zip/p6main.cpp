#include <cstdlib>
#include <iostream>
#include <fstream>
#include <ctime>
#include "p6spec.h"
#include "stringFunctions.h"


using namespace std;

void loadSymbols(symbol *symPtr, char *filePtr);

int main(){

	srand(time(NULL));
	
	char *filePtr = new char[7];

	symbol *symPtr = new symbol[7];

	reel *reelPtr = new reel[3];

	cout << "What is the name of the symbols file? (Hint: type 's' and press enter)" << endl;
	cin >> filePtr;

	//load symbols
	loadSymbols(symPtr, filePtr);
	
	/*test
	for(int i=0; i<6; i++){
	cout << symPtr[i].getName(symPtr) << endl;
	}*/

	//load reels
	for(int i=0; i<3; i++){
		reelPtr[i].setReel(symPtr, reelPtr);
	}

	//menu
	char input;

	//create menu and correspond numbers to program functions
	bool running = true;
	do{
		//print menu
		cout << endl;	
		cout <<"------------------------------MENU----------------------------"<<endl;
		cout <<"1. Populate a New Slot Machine"<<endl;
		cout <<"2. Print Slot Configuration to Screen"<<endl;
		cout <<"3. Pick a Reel # Stop # to See Designated Symbol and Value"<<endl;
		cout <<"4. Spin the Reels"<<endl;
		cout <<"Q: Quit"<<endl;
		cout <<"---------------------------------------------------------------"<<endl;
		cout << endl;

		//get command from user
		cout << "Pick an Option 1-4 or Q and Press Enter" << endl;
		cin >> input;
		cout << endl << endl << endl;

		switch(input){

			//populate new machine
			case '1':
			for(int i=0; i<3; i++){
				reelPtr[i].setReel(symPtr, reelPtr);
			}
			cout << "****************YOUR SLOT MACHINE HAS BEEN POPULATED*******************" << endl;
			cout << endl << endl << endl << endl << endl << endl << endl; 
			break;


			//print reel config. to screen
			case '2':
			cout << "------REEL CONFIGURATION------" << endl;
			(*reelPtr).printReel(reelPtr);
			cout << endl << endl << endl;
			break;


			//pick a reel and stop number, print symbol & value
			case '3':
			(*reelPtr).pickAndPrint(reelPtr);
			break;
			
			//spin the reels
			case '4':
			(*reelPtr).spinReels(reelPtr);
			break;

			//quit
			case 'q': case 'Q':
			cout << "*********************Thanks For Playing*********************" << endl;
			cout << "**********(And Remember: Gambling Is A Terrible Habit)***********" <<endl;
			cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
			cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
			running = false;
			break;
			
			//if option is invalid, respond "invalid entry"
			default:
			cout << "******************INVALID ENTRY, PLEASE TRY AGAIN*****************" << endl;
			cout << endl << endl << endl << endl << endl << endl << endl;
			
			break;		
			
		}

	}while(running);

	delete []filePtr;
	filePtr = NULL;
	delete []symPtr;
	symPtr = NULL;
	delete []reelPtr;
	reelPtr = NULL;

	return 0;
}

void loadSymbols(symbol *symPtr, char *filePtr){
	ifstream fin;
	fin.open(filePtr);

	char *tempName = new char[20];

	int val;

	for(int i=0; i<6; i++){
		//read in symbol name to temp file
		fin >> tempName;
		fin >> val;
		//cout << tempName;

		//set name, value, bonus using file
		symPtr[i].setName(tempName);

		symPtr[i].setValue(val);
		
		symPtr[i].setBonus(val);
		
	}
	delete []tempName;
	tempName = NULL;
	fin.close();

}

