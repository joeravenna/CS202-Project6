#include "stringFunctions.h"

using namespace std;

char *dest = new char[10];
char *source = new char[10];
char *str1 = new char[10];
char *str2 = new char[10];
char *str = new char[10];

//function: string copy
//purpose: copy a string character by character to a given destination
void strCopy(char *dest, char *source){
	int i=0;
	while(source[i]!='\0'){
		dest[i] = source[i];
		i++;
	}
	dest[i] = '\0';
}


//function: string compare
//purpose: compare strings character by character
bool strComp(char *str1, char *str2){
	bool equals = true;
	int i=0;
	while(str1[i]!='\0' && str2[i]!='\0' && equals){
		if(str1[i]!=str2[i]){
			equals=false;
		}
		i++;
	}

	if(str1[i]!=str2[i]){
		equals=false;
	}
	return equals;			
}


//function: string length
//purpose: determine the number of characters of a string
int strLen(char *str){
	int length=0;
	int i=0;
	while(str[i]!='\0'){
		length++;
		i++;
	}
	
	return length;
}

/*
//function: string combine
//function: combine two strings into one string
char* strCat(char *str1, char *str2){

	char *cat= new char[20];
	char *catHome;
	catHome = cat;
	
	int i=0;

	while(*str1[i]!='\0'){
		*cat = *str1;
		i++;
		cat++;
	}

	while (*str2[i]!='0'){
		*cat = *str2;
		i++;
		cat++;
	}
	
	cat = catHome;

	return cat;
	
}*/


