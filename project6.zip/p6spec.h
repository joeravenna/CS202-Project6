#include <cstdlib>
#include <ctime>

using namespace std;


class symbol{
	public:
		//default constructor
		symbol();
		//copy constructor, use const and pass by reference
		void symbolCopy(const symbol &s);

		//destructor
		~symbol();
			
		//set functions
		void setName(char *tempName);
		void setValue(int val);
		void setBonus(int val);

		//get functions, use const
		char* getName() const;
		int getValue() const;
		bool getBonus() const;
		
		//print functions
		void printSym();
		void printVal();
		
	
	private:
		char *name;
		int value;
		bool bonus;

};

class reel{
	public:
		//default constructor
		reel();
		//copy constructor (use const)
		void reelCopy(const reel &r);

		//destructor
		~reel();

		//FUNCTIONALITY
		//set functions
		void setReel(symbol *symPtr, reel *reelPtr);	

		//pick and print
		void pickAndPrint(reel *reelPtr);
		
		//spin reel
		void spinReels(reel *reelPtr);

		//print reel (use const)
		void printReel(reel *reelPtr);

	private:
		symbol *stopPtr;
		int payline;


};
