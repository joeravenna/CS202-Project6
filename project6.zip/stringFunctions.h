void strCopy(char *dest, char *source);
bool strComp(char *str1, char *str2);
int strLen(char *str);
//char* strCat(char *str1, char *str2);

